const express = require("express");
const app = express();

var bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);

var buscaCep = require("busca-cep");

const axios = require("axios");

app.use(express.static("public"));

app.get("/", (request, response) => {
  response.sendFile(__dirname + "/views/index.html"); // view do Sex Bot
});

app.post("/webhook", function (request, response) {
  //response.json({fulfillmentText: "Testando"});

  var intentName = request.body.queryResult.intent.displayName;

  if (intentName == "Default Welcome Intent") {
    response.json({
      fulfillmentMessages: [
        {
          card: {
            title: "Sex Shop",
            subtitle: "Desejamos que tenha uma ótima experiência!",
            imageUri:
              "https://cdn.glitch.global/cab68ad4-42f8-4686-ac87-3b0c162ccf78/imagem-sex-shop.png?v=1681401123065",
          },
        },
        {
          text: {
            text: ["Olá! Bem-vindo ao Sex Bot!"],
          },
        },
        {
          text: {
            text: ["Gostaria de acessar o nosso menu?"],
          },
        },
      ],
    });
  }

  if (intentName == "Default Welcome Intent - yes") {
    response.json({
      fulfillmentMessages: [
        {
          text: {
            text: ["Você gostaria de: "],
          },
        },
        {
          text: {
            text: ["1. Cadastrar pedido"],
          },
        },
        {
          text: {
            text: ["2. Atualizar pedido"],
          },
        },
        {
          text: {
            text: ["3. Consultar pedido"],
          },
        },
        {
          text: {
            text: ["4. Cancelar pedido"],
          },
        },
        {
          text: {
            text: ["5. Sair do Sex Bot"],
          },
        },
      ],
    });
  }

  if (
    intentName == "Default Welcome Intent - no" ||
    intentName == "Default Welcome Intent - yes - sair" ||
    intentName ==
      "Default Welcome Intent - yes - cadastrar - no - alterar - sair" ||
    intentName == "Default Welcome Intent - yes - cadastrar - sair"
  ) {
    response.json({
      fulfillmentMessages: [
        {
          card: {
            imageUri:
              "https://cdn.glitch.global/cab68ad4-42f8-4686-ac87-3b0c162ccf78/imagem-sex-shop.png?v=1681401123065",
          },
        },
        {
          text: {
            text: ["Obrigada por usar o Sex Bot!"],
          },
        },
        {
          text: {
            text: ["Esperamos que retorne logo!"],
          },
        },
      ],
    });
  }

  if (intentName == "Default Welcome Intent - yes - cadastrar") {
    var cep = request.body.queryResult.parameters["cep"];

    buscaCep(cep, { sync: false, timeout: 1000 }).then((endereco) => {
      var nome = request.body.queryResult.parameters["nome"];
      var cpf = request.body.queryResult.parameters["cpf"];
      var email = request.body.queryResult.parameters["email"];
      var produto = request.body.queryResult.parameters["produto"];
      var tamanho = request.body.queryResult.parameters["tamanho"];
      var quantidade = request.body.queryResult.parameters["quantidade"];
      var entrega = request.body.queryResult.parameters["entrega"];

      var endereco_cliente =
        endereco.logradouro +
        "-" +
        endereco.bairro +
        "," +
        endereco.localidade +
        "-" +
        endereco.uf +
        "--" +
        endereco.cep;

      response.json({
        fulfillmentMessages: [
          {
            text: {
              text: ["Confira os dados do seu pedido: "],
            },
          },
          {
            text: {
              text: ["Nome: " + nome],
            },
          },
          {
            text: {
              text: ["CPF: " + cpf],
            },
          },
          {
            text: {
              text: ["Endereço: " + endereco_cliente],
            },
          },
          {
            text: {
              text: ["Email: " + email],
            },
          },
          {
            text: {
              text: ["Produto: " + produto],
            },
          },
          {
            text: {
              text: ["Tamanho: " + tamanho],
            },
          },
          {
            text: {
              text: [
                "Digite 'Sim' para confirmar e 'Sair' para cancelar o cadastro.",
              ],
            },
          },
        ],
      });
    });
  }

  if (intentName == "Default Welcome Intent - yes - cadastrar - yes") {
    var nome = request.body.queryResult.parameters["nome"];
    var cep = request.body.queryResult.parameters["cep"];
    var cpf = request.body.queryResult.parameters["cpf"];
    var email = request.body.queryResult.parameters["email"];
    var produto = request.body.queryResult.parameters["produto"];
    var tamanho = request.body.queryResult.parameters["tamanho"];
    var quantidade = request.body.queryResult.parameters["quantidade"];
    var entrega = request.body.queryResult.parameters["entrega"];

    const dados = [
      {
        Nome: nome,
        CPF: cpf,
        CEP: cep,
        Email: email,
        Produto: produto,
        Tamanho: tamanho,
        Quantidade: quantidade,
        Entrega: entrega,
      },
    ];

    axios.post("https://sheetdb.io/api/v1/kevkhlt4ksluo", dados);

    response.json({
      fulfillmentMessages: [
        {
          card: {
            imageUri:
              "https://cdn.glitch.global/cab68ad4-42f8-4686-ac87-3b0c162ccf78/01.webp?v=1681407008520",
          },
        },
        {
          text: {
            text: [
              "Seu pedido foi registrado, " +
                nome +
                ". As informações serão enviadas no seu e-mail!",
            ],
          },
        },
      ],
    });
  }

  if (intentName == "Default Welcome Intent - yes - atualizar") {
    var cpf = request.body.queryResult.parameters["cpf"];
    var nome = request.body.queryResult.parameters["nome"];
    var entrega = request.body.queryResult.parameters["entrega"];

    const dados = [
      {
        Nome: nome,
        Entrega: entrega,
      },
    ];

    axios
      .patch("https://sheetdb.io/api/v1/kevkhlt4ksluo/CPF/" + cpf, dados)
      .then((res) => {
        response.json({
          fulfillmentText:
            "Pedido atualizado com sucesso! As informações serão enviadas por e-mail!",
        });
      })
      .catch((error) => {
        console.log(error),
          response.json({
            fulfillmentText: "Não foi possível atualizar o pedido!",
          });
      });
  }

  if (intentName == "Default Welcome Intent - yes - consultar") {
    var cpf = request.body.queryResult.parameters["cpf"];

    return axios
      .get("https://sheetdb.io/api/v1/kevkhlt4ksluo?CPF=" + cpf)
      .then((res) => {
        res.data.map((person) => {
          response.json({
            fulfillmentMessages: [
              {
                card: {
                  title: "Consultando seu pedido!",
                  imageUri:
                    "https://cdn.glitch.global/cab68ad4-42f8-4686-ac87-3b0c162ccf78/imagem-consulta.jpg?v=1681401127907",
                },
              },
              {
                text: {
                  text: ["Nome = " + person.Nome],
                },
              },
              {
                text: {
                  text: ["CEP = " + person.CEP],
                },
              },
              {
                text: {
                  text: ["E-mail = " + person.Email],
                },
              },
              {
                text: {
                  text: ["Produto = " + person.Produto],
                },
              },
              {
                text: {
                  text: ["Tamanho = " + person.Tamanho],
                },
              },
              {
                text: {
                  text: ["Quantidade = " + person.Quantidade],
                },
              },
              {
                text: {
                  text: ["Entrega = " + person.Entrega],
                },
              },
              {
                text: {
                  text: ["Obrigada por usar o Sex Bot!"],
                },
              },
            ],
          });
        });
      });
  }

  if (intentName == "Default Welcome Intent - yes - cancelar") {
    var cpf = request.body.queryResult.parameters["cpf"];

    axios
      .delete("https://sheetdb.io/api/v1/kevkhlt4ksluo/CPF/" + cpf)
      .then((res) => {
        response.json({
          fulfillmentText: "Pedido cancelado com sucesso!",
        });
      })
      .catch((error) => {
        response.json({
          fulfillmentText: "Não foi possível atualizar o pedido!",
        });
      });
  }
});

// listen for requests
const listener = app.listen(process.env.PORT, () => {
  console.log("Your app is listening on port " + listener.address().port);
});
